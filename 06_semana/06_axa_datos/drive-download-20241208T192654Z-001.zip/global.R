### global.R ###
# Cargar librerías necesarias
library(shiny)
library(shinydashboard)
library(shinydashboardPlus)
library(tidyverse)
library(plotly)
library(DT)
library(lubridate)
library(scales)
library(prophet)
library(survival)
library(caret)
